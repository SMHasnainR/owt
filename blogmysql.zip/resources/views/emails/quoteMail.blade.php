<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
        <h4> Name: </h4> <p> {{$details['First Name']}} {{$details['Last Name']}}</p>
        <h4> Email: </h4> <p>{{$details['Email']}}</p>
        <h4> Message: </h4> <p>  {{$details['Message']}}</p>
        <!-- <p>Thank You</p> -->
</body>
</html>