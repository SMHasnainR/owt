<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Mail</title>
</head>
<body>
        <p> <b> Name: </b> {{$details['Name']}}</p>
        <p> <b> Email: </b> {{$details['Email']}}</p>
        <p> <b> Subject: </b> {{$details['Subject']}}</p> 
        <p> <b> Message: </b> {{$details['Message']}}</p>
        <!-- <p>Thank You</p> -->
</body>
</html>