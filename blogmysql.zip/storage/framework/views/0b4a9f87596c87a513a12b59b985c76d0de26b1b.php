<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
        <h4> Name: </h4> <p> <?php echo e($details['First Name']); ?> <?php echo e($details['Last Name']); ?></p>
        <h4> Email: </h4> <p><?php echo e($details['Email']); ?></p>
        <h4> Message: </h4> <p>  <?php echo e($details['Message']); ?></p>
        <!-- <p>Thank You</p> -->
</body>
</html><?php /**PATH C:\Hasnain\Portfolio\optics\blogmysql\resources\views/emails/quoteMail.blade.php ENDPATH**/ ?>