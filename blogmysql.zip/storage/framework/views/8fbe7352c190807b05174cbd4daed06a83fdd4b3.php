
<?php $__env->startSection('content'); ?>


<!-- ======= Header Section ======= -->
<section id="portfolio-header" class="clearfix back-hero">
    <div class="container d-flex align-items-center h-100">
        <div class="row" data-aos="fade-up">
            <div class="col-md-12 intro-info" data-aos="zoom-in" data-aos-delay="100">
                <!-- <h2>We help <span> add value </span>through technology, custom built for your needs.</h2> -->
                <div class="d-flex justify-content-center">
                    <center><h2 class="head-h2">We help companies <span>plan, create and  deliver</span> integrated product and brand experiences</h2></center>
                </div>
            </div>
            <!-- <div class="col-md-6 intro-img order-md-last order-first" data-aos="zoom-out" data-aos-delay="200">
                <img src="<?php echo e(asset('assets/img/intro-img.svg')); ?>" alt="" class="img-fluid">
            </div> -->
        </div>
    </div>
</section>
<!-- End Hero -->



<!-- ======= Portfolio Section ======= -->
<section id="portfolio" class="portfolio section-bg mt-5">
    <div class="container" data-aos="fade-up">

        <header class="section-header">
            <h3 class="section-title">Our Portfolio</h3>
        </header>

        <div class='row'>
            <embed src="/assets/files/profile.pdf" type="application/pdf" width="100%" height="400px">
        </div>


    </div>
</section><!-- End Portfolio Section -->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Hasnain\Portfolio\optics\blogmysql\resources\views/portfolio.blade.php ENDPATH**/ ?>