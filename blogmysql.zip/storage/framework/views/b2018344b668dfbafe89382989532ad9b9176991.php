<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Mail</title>
</head>
<body>
        <p> <b> Name: </b> <?php echo e($details['Name']); ?></p>
        <p> <b> Email: </b> <?php echo e($details['Email']); ?></p>
        <p> <b> Subject: </b> <?php echo e($details['Subject']); ?></p> 
        <p> <b> Message: </b> <?php echo e($details['Message']); ?></p>
        <!-- <p>Thank You</p> -->
</body>
</html><?php /**PATH C:\Hasnain\Portfolio\optics\blogmysql\resources\views/emails/contactMail.blade.php ENDPATH**/ ?>